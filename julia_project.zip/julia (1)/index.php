<?php
header("Location: ./template/login.php");
exit();
?>


